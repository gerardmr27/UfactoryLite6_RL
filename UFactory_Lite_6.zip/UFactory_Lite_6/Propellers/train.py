from env import Lite6_propellers
import os
import pandas as pd
from stable_baselines3 import PPO
import numpy as np
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.callbacks import BaseCallback, EvalCallback, StopTrainingOnNoModelImprovement
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3 import TD3
from stable_baselines3.common.noise import NormalActionNoise, OrnsteinUhlenbeckActionNoise
import matplotlib.pyplot as plt

modelname = f"ppo_3"

model_dir = f"models/" + modelname

tensorboard_dir = f"./tensorboard/" + modelname

env_dir = f"envs/" + modelname + f".pkl"

env = make_vec_env(lambda:Lite6_propellers(),n_envs=4)

model = PPO("MlpPolicy", env, verbose=1,learning_rate=0.0003,tensorboard_log=tensorboard_dir)

model.learn(total_timesteps=4000000, progress_bar=True)

model.save(model_dir)








