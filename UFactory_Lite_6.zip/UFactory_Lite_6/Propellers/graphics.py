import pandas as pd
import matplotlib.pyplot as plt


modelname = "ppo_2"
data_dir = "./datos/" + modelname + "/" + modelname + "_mean_reward_train.csv"

tabla = pd.read_csv(data_dir)

x_steps = tabla['Step']
y_mean_rw  = tabla['Value']
plt.plot(x_steps,y_mean_rw)
plt.title('Recompensa media de los episodios de entrenamiento')
plt.xlabel("Timestep")
plt.ylabel("Recompensa media")
plt.savefig("./datos/" + modelname + "/" + modelname + "_mean_reward_train.png")
plt.show()