
from stable_baselines3 import PPO
import numpy as np
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.vec_env import VecNormalize
import mujoco
import mujoco.viewer
import gymnasium as gym
from gymnasium import spaces
import pygame
import random

class Lite6_propellers(gym.Env):

    def __init__(self):

        super(Lite6_propellers, self).__init__()

        xml_path = "/home/gerard/.mujoco/mujoco-3.1.1/projects/UFactory_Lite_6/ufactory_lite6/lite6.xml"
        self.reward = 0
        self.total_reward = 0
        self.done = False
        self.timestep = 0
        self.model = mujoco.MjModel.from_xml_path(xml_path)
        self.ep_length = 3500
        self.data = mujoco.MjData(self.model)

        self.sat_id = mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_BODY,'sat')
        self.dock_id = mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_SITE,'dockPoint')

        self.prev_pos = [0, 0, 0.55]

        self.target_pos = [random.uniform(-0.15,0.15),random.uniform(-0.15,0.15),1]
        self.model.site('target').pos[:] = self.target_pos

        self.initial_state = np.zeros(mujoco.mj_stateSize(self.model, mujoco.mjtState.mjSTATE_PHYSICS))
        mujoco.mj_getState(self.model,self.data,self.initial_state, mujoco.mjtState.mjSTATE_PHYSICS)


        self.joints = np.zeros(6)
        self.action = np.zeros(6)

        self.action_space = spaces.Box(low=0, high=1, shape=(6,)) 
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(18,))
        self.state = self._get_observation()

        self.high = np.zeros(6)
        self.high[:] = 50

    def reset(self,seed=None):

        if seed is not None:
            np.random.seed(seed)

        mujoco.mj_setState(self.model,self.data,self.initial_state,mujoco.mjtState.mjSTATE_PHYSICS)

        self.action = np.zeros(6)
        self.total_reward = 0
        self.reward = 0
        self.done = False
        self.timestep = 0
        self.prev_pos = [0, 0, 0.55]
        self.target_pos = [random.uniform(-0.15,0.15),random.uniform(-0.15,0.15),1]
        self.model.site('target').pos[:] = self.target_pos

        self.state = self._get_observation()


        return self.state, {}

    def step(self, action):

        self.timestep += 1

        action = action*self.high
        self.action = action

        self.data.ctrl[:] = self.joints
        forces = action[::2] - action[1::2]
        self.data.xfrc_applied[self.sat_id] = np.concatenate([forces,[0,0,0]])
        mujoco.mj_step(self.model,self.data)

        self.state = self._get_observation()

        reward, distance_sat, prop_consume = self._get_reward(self.state)
        self.reward=reward
        self.total_reward+=reward
        self.done = self._get_done(self.state)

        truncated = (self.timestep >= self.ep_length)

        info = {
            "distance_sat": distance_sat,
            "done": self.done,
            "truncated":truncated,
            "consume": prop_consume
        }

        return self.state, self.reward, self.done, truncated, info

    def _get_observation(self):

        sat_vel = self.data.cvel[self.sat_id][3:]
        sat_pos = self.data.site_xpos[self.dock_id].flat
        
        state = np.concatenate([sat_pos,self.target_pos,sat_vel,self.action,self.prev_pos],dtype='float32')

        return state

    def _get_reward(self,state):

        sat_pos = state[:3]
        desired_pos = state[3:6]
        sat_vel = state[6:9]
        action = state[9:15]
        prev_pos = state[15:18]
        
        distance_sat = np.linalg.norm(sat_pos - desired_pos)
        prev_distance = np.linalg.norm(prev_pos - desired_pos)

        err_rad = 0.1

        w1 = 10
        w2 = -0.0001
        w3 = -0.000001
        w4 = 2
        wt = -1
        sigma = 0.8
        k1=0
        dt = 0.002

        g0 = 9.8
        I = 200

        if distance_sat <= err_rad:
            k1=1
            self.done = True

        propellers_consume = (np.sum(action)/(I*g0))*dt

        reward = -(distance_sat - prev_distance) + w2*propellers_consume + w3*np.linalg.norm(sat_vel) + w4*k1
        self.prev_pos = sat_pos

        return reward,distance_sat,propellers_consume

    def _get_done(self,state):

        actual_pos = state[:3]
        desired_pos = state[3:6]

        finish = False

        distance = np.linalg.norm(actual_pos - desired_pos)

        if distance < 0.1:
            finish=True


        return self.done or finish

