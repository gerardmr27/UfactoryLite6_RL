from env import Lite6_propellers
from stable_baselines3 import PPO
import numpy as np
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.env_util import make_vec_env
from scipy.stats import linregress

import mujoco
import mujoco.viewer
import gymnasium as gym
from gymnasium import spaces
import pygame
import matplotlib.pyplot as plt
import os

modelname = f"ppo_2"

model_dir = f"models/" + modelname

tensorboard_dir = f"./tensorboard/" + modelname

env_dir = f"envs/" + modelname + f".pkl"

data_dir = "./datos/" + modelname

if not os.path.exists(data_dir):
    os.mkdir(data_dir)

env = make_vec_env(lambda: Lite6_propellers())

env.training = False

model = PPO.load(model_dir)

succeeded=0
failed=0

fig = plt.figure()

d = []
t = []
c = []
init_dist = 0
total_consume = 0
reduce = 0
slope_mean = 0
intercept_mean = 0

with mujoco.viewer.launch_passive(env.envs[0].model,env.envs[0].data) as viewer:
    env = env.envs[0]
    obs, _ = env.reset()
    while((succeeded+failed) != 100):
        action, _states = model.predict(obs)
        obs, reward, done, truncated, info = env.step(action)
        viewer.sync()
        if(env.timestep == 1):
            init_dist = info['distance_sat']
        t.append(env.timestep)
        d.append(info['distance_sat'])
        c.append(info['consume'])
        
        if done:
            plt.plot(t,d)
            plt.title("Distancia al objetivo")
            plt.xlabel("Timestep")
            plt.ylabel("Distancia (m)")
            total_consume += np.sum(c)
            slope, intercept, _, _, _ = linregress(t,d)
            slope_mean += slope
            intercept_mean += intercept
            if(info['distance_sat'] < init_dist):
                reduce+=1
            init_dist = 0
            t=[]
            d=[]
            c=[]
            succeeded+=1
            obs, _ = env.reset()

        elif truncated:
            plt.plot(t,d)
            plt.title("Distancia al objetivo")
            plt.xlabel("Timestep")
            plt.ylabel("Distancia (m)")
            total_consume += np.sum(c)
            slope, intercept, _, _, _ = linregress(t,d)
            slope_mean += slope
            intercept_mean += intercept
            if(info['distance_sat'] < init_dist):
                reduce+=1
            init_dist = 0
            t=[]
            d=[]
            c=[]
            failed+=1
            obs, _ = env.reset()

env.close()

average = (succeeded/(succeeded+failed))*100
consume = total_consume/100
slope_mean = slope_mean/100
intercept_mean = intercept_mean/100
plt.plot(np.arange(3501),intercept_mean + slope_mean*np.arange(3501),color="black",linewidth=2,linestyle="--")
plt.savefig(data_dir + "/" + modelname + "_results.png")

print("Porcentaje de alcances: {}%".format(average))
print("Consumo medio por episodio: {} kg".format(consume))
print("Porcentaje de episodios buenos: {}%".format(reduce))
print(f"Media de pendiente de recta: {slope_mean}")
