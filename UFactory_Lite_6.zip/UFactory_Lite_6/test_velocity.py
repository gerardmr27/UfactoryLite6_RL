import gymnasium as gym
import time
from stable_baselines3 import PPO, SAC

def train_and_evaluate(env_id, algo_class, total_timesteps):
    env = gym.make(env_id)
    model = algo_class("MlpPolicy", env, verbose=0)
    
    start_time = time.time()
    model.learn(total_timesteps=total_timesteps)
    end_time = time.time()
    
    elapsed_time = end_time - start_time
    iterations_per_second = total_timesteps / elapsed_time
    
    env.close()
    return iterations_per_second

envs = ["Humanoid-v4", "Ant-v4", "InvertedPendulum-v4"]
total_timesteps = 100000

results = {}

for env_id in envs:
    results[env_id] = {}
    
    print(f"Training PPO on {env_id}")
    ppo_iterations_per_second = train_and_evaluate(env_id, PPO, total_timesteps)
    results[env_id]['PPO'] = ppo_iterations_per_second
    
    print(f"Training SAC on {env_id}")
    sac_iterations_per_second = train_and_evaluate(env_id, SAC, total_timesteps)
    results[env_id]['SAC'] = sac_iterations_per_second

# Print results
for env_id, res in results.items():
    print(f"\nResults for {env_id}:")
    print(f"PPO: {res['PPO']} iterations/second")
    print(f"SAC: {res['SAC']} iterations/second")