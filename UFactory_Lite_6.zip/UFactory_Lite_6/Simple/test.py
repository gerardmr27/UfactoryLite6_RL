from env import Lite6_simple
from stable_baselines3 import PPO
import numpy as np
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.env_util import make_vec_env

import mujoco
import os
import mujoco.viewer
import gymnasium as gym
from gymnasium import spaces
import pygame
import matplotlib.pyplot as plt
import random


modelname = f"ppo_9"

model_dir = f"models/" + modelname

tensorboard_dir = f"./tensorboard/" + modelname

env_dir = f"envs/" + modelname + f".pkl"

data_dir = "./datos/" + modelname
if not os.path.exists(data_dir):
    os.mkdir(data_dir)

env = make_vec_env(lambda: Lite6_simple())

env = VecNormalize.load(env_dir, env)

env.training = False

env.norm_reward = False

model = PPO.load(model_dir)

succeeded=0
failed=0

t = []
d = []
v = []

meanV = 0
stdV = 0



env = env.envs[0]

with mujoco.viewer.launch_passive(env.model,env.data) as viewer:
    sat_id = mujoco.mj_name2id(env.model,mujoco.mjtObj.mjOBJ_BODY,'link6')
    obs, _ = env.reset()
    while((succeeded+failed) != 100):
        action, _states = model.predict(obs)
        obs, reward, done, truncated, info = env.step(action)
        viewer.sync()
        t.append(env.timestep)
        d.append(info["distance2target"])
        v.append(np.linalg.norm(env.data.cvel[sat_id][3:]))
        
        if done:
            succeeded+=1
            meanV += np.mean(v)
            stdV += np.std(v)
            t=[]
            d=[]
            v = []
            obs, _ = env.reset()

        elif truncated:
            failed+=1
            meanV += np.mean(v)
            stdV += np.std(v)
            t=[]
            d=[]
            v = []
            obs, _ = env.reset()

env.close()



average = (succeeded/(succeeded+failed))*100
meanV = meanV/100
stdV = stdV/100


print("Porcentaje de alcances: {}%".format(average))
print(f"Media y desviación estándar: {meanV} +/- {stdV}")