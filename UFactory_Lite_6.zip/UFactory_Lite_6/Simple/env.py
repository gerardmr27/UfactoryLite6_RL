import mujoco
import mujoco.viewer
import numpy as np
import gymnasium as gym
from gymnasium import spaces
import pygame
import random

class Lite6_simple(gym.Env):

    def __init__(self):

        super(Lite6_simple, self).__init__()

        xml_path = "/home/gerard/.mujoco/mujoco-3.1.1/projects/UFactory_Lite_6/ufactory_lite6/lite6.xml"
        self.reward = 0
        self.total_reward = 0
        self.done = False
        self.timestep = 0
        self.model = mujoco.MjModel.from_xml_path(xml_path)
        self.ep_length = 4000
        self.data = mujoco.MjData(self.model)

        self.effector_id = mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_SITE,'attachment_site')
        self.target_pos = [random.uniform(-0.15,0.15),random.uniform(-0.15,0.15),1.2]
        self.model.site('target').pos[:] = self.target_pos


        self.initial_state = np.zeros(mujoco.mj_stateSize(self.model, mujoco.mjtState.mjSTATE_PHYSICS))
        mujoco.mj_getState(self.model,self.data,self.initial_state, mujoco.mjtState.mjSTATE_PHYSICS)

        self.prev_action = np.zeros(6)
        self.action = self.prev_action.copy()
        self.init_action = self.action.copy()
        self.contacts = 0

        self.action_space = spaces.Box(low=0, high=1, shape=(6,)) 
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(37,)) 
        self.state = self._get_observation()
        self.low = np.zeros(6)
        self.high = np.zeros(6)

        self.low = self.model.jnt_range[1:,0]
        self.high = self.model.jnt_range[1:,1]

    def reset(self,seed=None):

        if seed is not None:
            np.random.seed(seed)

        mujoco.mj_setState(self.model,self.data,self.initial_state,mujoco.mjtState.mjSTATE_PHYSICS)

        self.total_reward = 0
        self.done = False
        self.timestep = 0
        self.prev_action = self.init_action.copy()
        self.action = self.prev_action.copy()
        self.contacts = 0
        self.target_pos = [random.uniform(-0.15,0.15),random.uniform(-0.15,0.15),1.2]
        self.model.site('target').pos[:] = self.target_pos

        self.state = self._get_observation()


        return self.state, {}

    def step(self, action):

        self.timestep += 1
        action = action*(self.high - self.low) + self.low

        self.action = action
        self.data.ctrl[:] = action
        mujoco.mj_step(self.model,self.data)

        c=0
        for i in range(len(self.data.contact.geom1)):
            if(self.data.contact.geom1[i] == 1) and (self.data.contact.geom2[i] % 2 != 0):
                c+=1

        self.contacts = c

        self.state = self._get_observation()

        reward,distance = self._get_reward(self.state)
        self.reward=reward
        self.total_reward+=reward
        self.done = self._get_done(self.state)

        truncated = (self.timestep >= self.ep_length)

        info = {
            "distance2target": distance,
            "done": self.done,
            "truncated":truncated,
            "contacts":self.contacts

        }

        return self.state, self.reward, self.done, truncated, info

    def _get_observation(self):
        qpos = self.data.qpos[7:].flat
        qvel = self.data.qvel[6:].flat
        qacc = self.data.qacc[6:].flat
        end_effector_pos = self.data.site_xpos[self.effector_id].flat

        state = np.concatenate([qpos,qvel,qacc,end_effector_pos,self.target_pos,self.action,self.prev_action,[self.contacts]],dtype='float32')

        return state

    def _get_reward(self,state):

        qpos = state[:6]
        qvel = state[6:12]
        qacc = state[12:18]
        actual_pos = state[18:21]
        desired_pos = state[21:24]
        action = state[24:30]
        prev_action = state[30:36]
        contacts = state[36:]
        contacts = contacts[0]

        distance = np.linalg.norm(actual_pos - desired_pos)

        err_rad = 0.1

        w1 = 10
        w2 = -0.01
        w3 = -0.000005
        w4 = -0.01
        w5 = 0
        w6 = 2
        sigma = 0.25
        k1=0
        k2=0
        wc = 0
        wt = 0

        if distance < err_rad:
            k2=1
            self.done = True

        if contacts>0:
            k1=1

        Re = w1 * np.exp((-distance)/sigma)

        Rn = w2*np.sum(np.square(qvel)) + w3*np.sum(np.square(qacc)) + w4*np.sum(np.square(action-prev_action)) + w5*k1 + w6*k2 + wc*contacts + wt
        self.prev_action=action.copy()

        reward = Re + Rn



        return reward,distance

    def _get_done(self,state):

        actual_pos = state[18:21]
        desired_pos = state[21:24]

        finish = False

        distance = np.linalg.norm(actual_pos - desired_pos)

        if distance < 0.1:
            finish=True


        return self.done or finish
