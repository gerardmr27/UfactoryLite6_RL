
from stable_baselines3 import PPO
import numpy as np
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.vec_env import VecNormalize
import mujoco
import mujoco.viewer
import gymnasium as gym
from gymnasium import spaces
import random

class Lite6_advanced(gym.Env):

    def __init__(self):

        super(Lite6_advanced, self).__init__()

        xml_path = "/home/gerard/.mujoco/mujoco-3.1.1/projects/UFactory_Lite_6/ufactory_lite6/lite6.xml"
        self.reward = None
        self.total_reward = None
        self.done = False
        self.timestep = 0
        self.model = mujoco.MjModel.from_xml_path(xml_path)
        self.ep_length = 8000
        self.data = mujoco.MjData(self.model)

        self.sat_id = mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_BODY,'sat')
        self.dock_id = mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_SITE,'dockPoint')
        self.prev_pos = [0, 0, 0.55]

        self.target_pos = [random.uniform(-0.15,0.15),random.uniform(-0.15,0.15),1.5]
        self.model.site('target').pos[:] = self.target_pos

        self.initial_state = np.zeros(mujoco.mj_stateSize(self.model, mujoco.mjtState.mjSTATE_PHYSICS))
        mujoco.mj_getState(self.model,self.data,self.initial_state,mujoco.mjtState.mjSTATE_PHYSICS)

        self.prev_action = np.zeros(12)
        self.action = np.zeros(12)
        self.contacts = 0


        self.action_space = spaces.Box(low=0, high=1, shape=(12,)) 
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(58,))  
        self.state = self._get_observation()
        self.low = np.zeros(12)
        self.high = np.zeros(12)

        self.low[:6] = self.model.jnt_range[1:,0]
        self.high[:6] = self.model.jnt_range[1:,1]

        self.low[6:] = 0
        self.high[6:] = 50

    def reset(self,seed=None):

        if seed is not None:
            np.random.seed(seed)

        mujoco.mj_setState(self.model,self.data,self.initial_state,mujoco.mjtState.mjSTATE_PHYSICS)

        self.total_reward = 0
        self.done = False
        self.timestep = 0
        self.prev_action = np.zeros(12)
        self.action = np.zeros(12)
        self.prev_pos = [0, 0, 0.55]
        self.contacts = 0
        self.target_pos = [random.uniform(-0.15,0.15),random.uniform(-0.15,0.15),1.5]
        self.model.site('target').pos[:] = self.target_pos

        self.state = self._get_observation()


        return self.state, {}

    def step(self, action):

        self.timestep += 1

        action = action*(self.high - self.low) + self.low   

        self.action = action

        self.data.ctrl[:] = action[:6]
        forces = action[6:]
        forces = forces[::2] - forces[1::2]
        self.data.xfrc_applied[self.sat_id] = np.concatenate([forces,[0,0,0]])
        mujoco.mj_step(self.model,self.data)

        c=0
        for i in range(len(self.data.contact.geom1)):
            if(self.data.contact.geom1[i] == 1) and (self.data.contact.geom2[i] % 2 != 0):
                c+=1

        self.contacts = c

        self.state = self._get_observation()

        reward, distance_rob, distance_sat, consume = self._get_reward(self.state)
        self.reward=reward
        self.total_reward+=reward
        self.done = self._get_done(self.state)

        truncated = (self.timestep >= self.ep_length)

        info = {
            "reward": self.total_reward,
            "distance_rob": distance_rob,
            "distance_sat": distance_sat,
            "consume": consume

        }

        return self.state, self.reward, self.done, truncated, info

    def _get_observation(self):

        qpos = self.data.qpos[7:].flat
        qvel = self.data.qvel[6:].flat
        qacc = self.data.qacc[6:].flat

        end_effector_pos = self.data.site_xpos[mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_SITE,'attachment_site')].flat
        sat_vel = self.data.cvel[self.sat_id][3:]
        sat_pos = self.data.xpos[self.dock_id]

        state = np.concatenate([qpos,qvel,qacc,end_effector_pos,self.target_pos,self.action,self.prev_action,[self.contacts],sat_pos,sat_vel,self.prev_pos],dtype='float32')

        return state

    def _get_reward(self,state):

        qpos = state[:6]
        qvel = state[6:12]
        qacc = state[12:18]
        actual_pos = state[18:21]
        desired_pos = state[21:24]
        action = state[24:36]
        prev_action = state[36:48]
        contacts = state[48]
        sat_pos = state[49:52]
        sat_vel = state[52:55]
        prev_pos = state[55:58]

        distance_robot = np.linalg.norm(actual_pos - desired_pos)
        distance_sat = np.linalg.norm(sat_pos - desired_pos)
        prev_distance = np.linalg.norm(prev_pos - desired_pos)


        err_rad = 0.1
        dist_threshold = 1

        w1 = 10
        w2 = -0.01
        w3 = -0.000005
        w4 = -0.01
        w5 = 2
        w6 = -0.0001
        sigma = 0.25

        k = 0

        dt = 0.002

        g0 = 9.8
        I = 200

        propellers_consume = (np.sum(action[6:])/(I*g0))*dt

        reward = 0
        Re = 0
        Rn = 0

        if distance_robot < err_rad:
            k=1
            self.done = True

        if distance_sat <= dist_threshold:
            Re = w1 * np.exp((-distance_robot)/sigma)
            Rn = w2*np.sum(np.square(qvel)) + w3*np.sum(np.square(qacc)) + w4*np.sum(np.square(action[:6]-prev_action[:6])) + w5*k
            reward = Re + Rn

        else:
            reward = -(distance_sat - prev_distance) + w6*propellers_consume

        self.prev_action=action
        self.prev_pos = sat_pos

        return reward,distance_robot,distance_sat,propellers_consume

    def _get_done(self,state):

        actual_pos = state[18:21]
        desired_pos = state[21:24]

        finish = False

        distance = np.linalg.norm(actual_pos - desired_pos)

        if distance < 0.1:
            finish=True


        return self.done or finish

