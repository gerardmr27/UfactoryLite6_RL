from env import Lite6_advanced
from stable_baselines3 import PPO
import numpy as np
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.env_util import make_vec_env
import matplotlib.pyplot as plt
from scipy.stats import linregress
import os

import mujoco
import mujoco.viewer
import gymnasium as gym
from gymnasium import spaces
import pygame


modelname = f"ppo_1"

model_dir = f"models/" + modelname

tensorboard_dir = f"./tensorboard/" + modelname

env_dir = f"envs/" + modelname + f".pkl"

data_dir = "./datos/" + modelname

if not os.path.exists(data_dir):
    os.mkdir(data_dir)

env = make_vec_env(lambda: Lite6_advanced())

env.training = False

model = PPO.load(model_dir)

succeeded=0
failed=0

fig = plt.figure()

d = []
d_r = []
t = []
c = []
slope_mean = 0
intercept_mean = 0
total_consume = 0

with mujoco.viewer.launch_passive(env.envs[0].model,env.envs[0].data) as viewer:
    env = env.envs[0]
    obs, _ = env.reset()
    while((succeeded+failed) != 100):
        action, _states = model.predict(obs)
        obs, reward, done, truncated, info = env.step(action)
        viewer.sync()
        
        if(env.timestep == 1):
            init_dist = info['distance_sat']
        t.append(env.timestep)
        d.append(info['distance_sat'])
        d_r.append(info['distance_rob'])
        c.append(info['consume'])
        
        if done:
            plt.plot(t,d)
            plt.title("Distancia de la nave al objetivo")
            plt.xlabel("Timestep")
            plt.ylabel("Distancia (m)")
            slope, intercept, _, _, _ = linregress(t,d)
            slope_mean += slope
            intercept_mean += intercept
            total_consume += np.sum(c)

            t=[]
            d=[]
            c=[]
            d_r=[]
            succeeded+=1
            obs, _ = env.reset()
            print('Alcanzado objetivo')

        elif truncated:
            plt.plot(t,d)
            plt.title("Distancia de la nave al objetivo")
            plt.xlabel("Timestep")
            plt.ylabel("Distancia (m)")
            total_consume += np.sum(c)
            slope, intercept, _, _, _ = linregress(t,d)
            slope_mean += slope
            intercept_mean += intercept
            t=[]
            d=[]
            c=[]
            d_r=[]
            failed+=1
            obs, _ = env.reset()
            print('Episodio truncado')

env.close()
slope_mean = slope_mean/100
intercept_mean = intercept_mean/100
plt.plot(np.arange(8001),intercept_mean + slope_mean*np.arange(8001),color="black",linewidth=2,linestyle="--")
plt.savefig(data_dir + "/" + modelname + "_results.png")
average = (succeeded/(succeeded+failed))*100
consume = total_consume/100

print("Porcentaje de alcances: {}%".format(average))
print("Consumo medio por episodio: {} kg".format(consume))
print(f"Media de pendiente de recta: {slope_mean}")
